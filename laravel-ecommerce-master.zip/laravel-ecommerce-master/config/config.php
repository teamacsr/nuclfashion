<?php

return [
    /*
    |--------------------------------------------------------------------------
    | Product Eloquent Model
    |--------------------------------------------------------------------------
    |
    |
    |
    */
    'product_model' => 'ANavallaSuiza\Ecommerce\Product\Models\Product'
];
