<?php
namespace ANavallaSuiza\Ecommerce\Promotion\Models;

interface CouponInterface
{

}
