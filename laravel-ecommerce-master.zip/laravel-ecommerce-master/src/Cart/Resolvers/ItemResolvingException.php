<?php
namespace ANavallaSuiza\Ecommerce\Cart\Resolvers;

class ItemResolvingException extends \InvalidArgumentException
{

}
