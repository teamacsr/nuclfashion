<?php
namespace ANavallaSuiza\Ecommerce\Cart\Models;

use ANavallaSuiza\Ecommerce\Order\Models\OrderItemInterface;

interface CartItemInterface extends OrderItemInterface
{

}
