<?php
namespace ANavallaSuiza\Ecommerce\Cart\Models;

use ANavallaSuiza\Ecommerce\Order\Models\OrderItem;

class CartItem extends OrderItem implements CartItemInterface
{

}
