<?php
namespace ANavallaSuiza\Ecommerce\Product\Observer;

class PropertyValueObserver
{
    public function creating($model)
    {
        $model->property->save();
    }
}
