<?php
namespace ANavallaSuiza\Ecommerce\Product\Models;

interface PropertyInterface
{

}
